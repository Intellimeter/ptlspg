use ptls ;
select * from
((select "Property", "SN", "Channel", "Time", "Utility", "Description", "Value", "Unit")
union
(select "Jefferson_Presidential_City", a.sn, i.chan, a.realreaddate, i.utility, i.descpt, a.tch1 * i.mtpr, i.unit 
from accum a, info i where a.sn=i.sn and i.chan=1 and a.RealReadDate >= "2017-02-16 00:00:00" and a.RealReadDate <= "2017-03-03 12:00:00" 
group by a.sn, a.readdate order by a.sn, a.readdate asc )
union 
(select "Jefferson_Presidential_City", a.sn, i.chan, a.realreaddate, i.utility, i.descpt, a.tch2 * i.mtpr, i.unit 
from accum a, info i where a.sn=i.sn and i.chan=2 and a.RealReadDate >= "2017-02-16 00:00:00" and a.RealReadDate <= "2017-03-03 12:00:00" 
group by a.sn, a.readdate order by a.sn, a.readdate asc )
union 
(select "Jefferson_Presidential_City", a.sn, i.chan, a.realreaddate, i.utility, i.descpt, a.tch3 * i.mtpr, i.unit 
from accum a, info i where a.sn=i.sn and i.chan=3 and a.RealReadDate >= "2017-02-16 00:00:00" and a.RealReadDate <= "2017-03-03 12:00:00" 
group by a.sn, a.readdate order by a.sn, a.readdate asc )
union 
(select "Jefferson_Presidential_City", a.sn, i.chan, a.realreaddate, i.utility, i.descpt, a.tch4 * i.mtpr, i.unit 
from accum a, info i where a.sn=i.sn and i.chan=4 and a.RealReadDate >= "2017-02-16 00:00:00" and a.RealReadDate <= "2017-03-03 12:00:00" 
group by a.sn, a.readdate order by a.sn, a.readdate asc )
union 
(select "Jefferson_Presidential_City", a.sn, i.chan, a.realreaddate, i.utility, i.descpt, a.tch5 * i.mtpr, i.unit 
from accum a, info i where a.sn=i.sn and i.chan=5 and a.RealReadDate >= "2017-02-16 00:00:00" and a.RealReadDate <= "2017-03-03 12:00:00" 
group by a.sn, a.readdate order by a.sn, a.readdate asc )
union 
(select "Jefferson_Presidential_City", a.sn, i.chan, a.realreaddate, i.utility, i.descpt, a.tch6 * i.mtpr, i.unit 
from accum a, info i where a.sn=i.sn and i.chan=6 and a.RealReadDate >= "2017-02-16 00:00:00" and a.RealReadDate <= "2017-03-03 12:00:00" 
group by a.sn, a.readdate order by a.sn, a.readdate asc )
union 
(select "Jefferson_Presidential_City", a.sn, i.chan, a.realreaddate, i.utility, i.descpt, a.tch7 * i.mtpr, i.unit 
from accum a, info i where a.sn=i.sn and i.chan=7 and a.RealReadDate >= "2017-02-16 00:00:00" and a.RealReadDate <= "2017-03-03 12:00:00" 
group by a.sn, a.readdate order by a.sn, a.readdate asc )
union 
(select "Jefferson_Presidential_City", a.sn, i.chan, a.realreaddate, i.utility, i.descpt, a.tch8 * i.mtpr, i.unit 
from accum a, info i where a.sn=i.sn and i.chan=8 and a.RealReadDate >= "2017-02-16 00:00:00" and a.RealReadDate <= "2017-03-03 12:00:00" 
group by a.sn, a.readdate order by a.sn, a.readdate asc )) A
INTO OUTFILE "C:/ptlspg/Jefferson_adhoc.csv" FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\r\n' ;
