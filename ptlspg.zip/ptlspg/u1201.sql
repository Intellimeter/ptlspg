use ptls ;
select * from
((select "Property", "SN", "Channel", "Time", "Utility", "Description", "Value", "Unit")
union
(select "Jefferson_Presidential_City", a.sn, i.chan, a.realreaddate, i.utility, i.descpt, a.tch1 * i.mtpr, i.unit 
from accum a, info i where a.sn=16808 and a.sn=i.sn and i.chan=1 and a.RealReadDate >= "2016-09-01 00:00:00" and a.RealReadDate <= "2017-02-03 00:00:00" 
group by a.sn, a.readdate order by a.sn, a.readdate asc )) A
INTO OUTFILE "C:/ptlspg/u1201.csv" FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\r\n' ;
